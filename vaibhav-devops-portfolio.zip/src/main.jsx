
import React from 'react'
import ReactDOM from 'react-dom/client'
import DevOpsPortfolio from './DevOpsPortfolio'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <DevOpsPortfolio />
  </React.StrictMode>
)
