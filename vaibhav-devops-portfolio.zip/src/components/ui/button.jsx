
export function Button({ children }) {
  return <button style={{ padding: '8px 16px', borderRadius: 4 }}>{children}</button>
}
